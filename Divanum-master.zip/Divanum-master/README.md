# Grupo Divanum

Nome do projeto: **Divanum**

Categoria: **WebApp (App Hibrido)**

Público-alvo: **Pessoas com possiveis problemas psicologicos, como depressão, pessoas solidarias, dispostas a ajudar outras pessoas e profissionais da área de psicologia**

Proposta de valor única: **O diagnóstico é feito em tempo real pelo Watson, o que é um grande diferencial em relação aos concorrentes. A aplicação possui o expertise de diversos profissionais e estará diagnosticando transtornos mentais com o conhecimento de todos eles. Aplicação web e mobile.**

Desafio: 

- [x] Bluemix
- [ ] GS1
- [x] Social

Participantes:

- Otavio R. Rossi
- Luccas Yoshimoto
- Guilherme Uezima
- Michel Zarzour
- Gustavo Sore
